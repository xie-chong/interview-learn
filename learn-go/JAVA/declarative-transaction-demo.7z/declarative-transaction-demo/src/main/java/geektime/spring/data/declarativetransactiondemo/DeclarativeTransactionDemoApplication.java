package geektime.spring.data.declarativetransactiondemo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication
@EnableTransactionManagement(mode = AdviceMode.PROXY)
@Slf4j
public class DeclarativeTransactionDemoApplication implements CommandLineRunner {
	@Autowired
	private FooService fooService;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private OutTransaction outTransaction;

	public static void main(String[] args) {
		SpringApplication.run(DeclarativeTransactionDemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		fooService.insertRecord();
		log.info("AAA-1 {}",
				jdbcTemplate
						.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='AAA'", Long.class));
//		try {
//			fooService.insertThenRollback();
//		} catch (Exception e) {
//			log.info("BBB-1 {}",
//					jdbcTemplate
//							.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='BBB'", Long.class));
//		}

		outTransaction.test();
//		try {
//			fooService.invokeInsertThenRollback();
//		} catch (Exception e) {
//			log.info("BBB {}",
//					jdbcTemplate
//							.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='BBB'", Long.class));
//		}
	}

//	@Transactional(rollbackFor = RollbackException.class)
//	void test(){
//		try {
//			fooService.insertRecord();
//			fooService.invokeInsertThenRollback();
//			log.info("AAA-2 {}",
//					jdbcTemplate
//							.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='AAA'", Long.class));
//			log.info("BBB-2 {}",
//					jdbcTemplate
//							.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='BBB'", Long.class));
//			throw new RuntimeException();
//		} catch (Exception e) {
//			log.info("AAA-3 {}",
//					jdbcTemplate
//							.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='AAA'", Long.class));
//			log.info("BBB-3 {}",
//					jdbcTemplate
//							.queryForObject("SELECT COUNT(*) FROM FOO WHERE BAR='BBB'", Long.class));
//		}
//	}
}

