package geektime.spring.data.declarativetransactiondemo;

public class RollbackException extends Exception {
}
